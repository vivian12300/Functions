import Cocoa

var greeting = "Hello, playground"


func add(a: Int, b: Int) -> Int{
    return a + b
}
print(add(a: 5, b: 10))
